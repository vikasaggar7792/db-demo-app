const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

const app = express();
const PORT = process.env.PORT || 3000;

// ✅ MUST DEFINE ENV VARIABLES
const mongoHost = process.env.MONGO_HOST || "service-mongodb";
const mongoPort = process.env.MONGO_PORT || "27017";

console.log("Mongo host:", mongoHost);
console.log("Mongo port:", mongoPort);

// ✅ CORRECT connection string
mongoose.connect(`mongodb://${mongoHost}:${mongoPort}/test`, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

const Email = mongoose.model('Email', {
    email: String,
});

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
});

app.post('/add-email', async (req, res) => {
    const { email } = req.body;
    try {
        await new Email({ email }).save();
        res.redirect('/');
    } catch (e) {
        res.status(500).send("DB error");
    }
});

app.get('/emails', async (req, res) => {
    const emails = await Email.find({});
    res.json(emails);
});

app.listen(PORT, () => {
    console.log(`Server running on ${PORT}`);
});

